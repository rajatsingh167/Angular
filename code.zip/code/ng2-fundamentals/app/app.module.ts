import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {AppComponent} from './app.component';
import {AppComponent2} from './product/product-list.component';
import {FormsModule } from '@angular/forms';
import {ProductService} from './product/ProductService.service';



@NgModule({
    imports:      [ BrowserModule ,FormsModule , HttpClientModule],
    declarations: [ AppComponent ,AppComponent2 ],
    bootstrap:    [ AppComponent ,AppComponent2],
    providers: [ProductService]
})

export class AppModule{ }

