import {Component} from '@angular/core';

@Component({
selector: 'my-app',
template:`<div>Hello {{name}} test</div>
<h1>rajat </h1>`,
})
export class AppComponent{ 
    name: string ='Angular';  
}