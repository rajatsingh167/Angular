export interface IProduct{
    productId:number;
    productName:string,
    productCode:String,
    releaseDate:Date,
    description:String,
    price: number,
    starRating: number,
    imageUrl: string;

    //calculateDiscount(percent : number):number;
}