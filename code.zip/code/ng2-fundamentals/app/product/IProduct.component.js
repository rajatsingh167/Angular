"use strict";
//# sourceMappingURL=IProduct.component.js.map