import {Component ,OnInit} from '@angular/core';
import {IProduct} from './IProduct.component';
import{FormsModule} from '@angular/forms';
import {ProductService} from './ProductService.service';

@Component({
    moduleId:module.id,
    selector: 'pm-products',
    templateUrl: `./product-list.component.html`,
   
})
export class AppComponent2 implements OnInit{ 
      constructor(private _productService : ProductService){ }
      pageTitle: string = 'Product List';
      showImage :boolean=false;
      showButton:String="Show Image";
      _listFilter:string;
      filteredProducts: IProduct[];
      products: IProduct[] ;

    get listFilter(): string {
        return this._listFilter;
    }
    set listFilter(value: string) {
      this._listFilter = value;
      this.filteredProducts =this.listFilter ?this.performFilter(this.listFilter):this.products;
    }


    toggleImage(){
        this.showImage= !this.showImage;
        this.showButton=this.showImage ?"Hide Image":"Show Image";
    }
    performFilter(filterBy:string) : IProduct[]{
        filterBy =filterBy.toLocaleLowerCase();
        return this.products.filter((products:IProduct) => products.productName.toLocaleLowerCase().indexOf(filterBy)!=-1);
    }
    ngOnInit() : void{
     this._productService.getProduct().subscribe(products => this.products =products ,  error => this.errorMessage =<any>Error)
}

}